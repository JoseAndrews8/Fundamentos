#include <iostream>
#include <string>
#include "Usuario.h"

using namespace std;

int main()
{
    string usuario, contrasenia;

    Usuario usuario1("Andrews", "123456789");

    cout << "Ingresar Usuario: ";
    cin >> usuario;

    cout << "Ingresar Password: ";
    cin >> contrasenia;

    if (usuario1.Verificarlogin(usuario, contrasenia)) 
        cout << "Puedes pasar" << endl;
    else
        cout << "Error no puedes pasar" << endl;
}
